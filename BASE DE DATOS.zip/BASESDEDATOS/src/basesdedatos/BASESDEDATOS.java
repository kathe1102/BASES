
package basesdedatos;

import basesdedatos.Menuprincipal;


public class BASESDEDATOS {

   
    public static void main(String[] args) {
       Menuprincipal op=new Menuprincipal();
       op.setVisible(true);
       
       op.setLocation(300,100);
       op.setSize(700, 400);
        
        
    }

   
    
}
