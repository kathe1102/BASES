/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ASEGURADORA;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author SEBASTIAN
 */
public class TBASEGURAMIENTOSTest {
    
    public TBASEGURAMIENTOSTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of cargatabla method, of class TBASEGURAMIENTOS.
     */
    @Test
    public void testCargatabla() {
        System.out.println("cargatabla");
        TBASEGURAMIENTOS instance = new TBASEGURAMIENTOS();
        instance.cargatabla();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of filtro1 method, of class TBASEGURAMIENTOS.
     */
    @Test
    public void testFiltro1() {
        System.out.println("filtro1");
        TBASEGURAMIENTOS instance = new TBASEGURAMIENTOS();
        instance.filtro1();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of filtro2 method, of class TBASEGURAMIENTOS.
     */
    @Test
    public void testFiltro2() {
        System.out.println("filtro2");
        TBASEGURAMIENTOS instance = new TBASEGURAMIENTOS();
        instance.filtro2();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of listardatos method, of class TBASEGURAMIENTOS.
     */
    @Test
    public void testListardatos() {
        System.out.println("listardatos");
        TBASEGURAMIENTOS instance = new TBASEGURAMIENTOS();
        instance.listardatos();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of listardatos2 method, of class TBASEGURAMIENTOS.
     */
    @Test
    public void testListardatos2() {
        System.out.println("listardatos2");
        TBASEGURAMIENTOS instance = new TBASEGURAMIENTOS();
        instance.listardatos2();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of registrar method, of class TBASEGURAMIENTOS.
     */
    @Test
    public void testRegistrar() {
        System.out.println("registrar");
        TBASEGURAMIENTOS instance = new TBASEGURAMIENTOS();
        instance.registrar();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of cargarcombo method, of class TBASEGURAMIENTOS.
     */
    @Test
    public void testCargarcombo() {
        System.out.println("cargarcombo");
        TBASEGURAMIENTOS instance = new TBASEGURAMIENTOS();
        instance.cargarcombo();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of cargarcombo2 method, of class TBASEGURAMIENTOS.
     */
    @Test
    public void testCargarcombo2() {
        System.out.println("cargarcombo2");
        TBASEGURAMIENTOS instance = new TBASEGURAMIENTOS();
        instance.cargarcombo2();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of modificar method, of class TBASEGURAMIENTOS.
     */
    @Test
    public void testModificar() {
        System.out.println("modificar");
        String ini = "";
        String xp = "";
        String val = "";
        String est = "";
        String os = "";
        String pla = "";
        String cod = "";
        TBASEGURAMIENTOS instance = new TBASEGURAMIENTOS();
        instance.modificar(ini, xp, val, est, os, pla, cod);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of eliminar method, of class TBASEGURAMIENTOS.
     */
    @Test
    public void testEliminar() {
        System.out.println("eliminar");
        String cod = "";
        TBASEGURAMIENTOS instance = new TBASEGURAMIENTOS();
        instance.eliminar(cod);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class TBASEGURAMIENTOS.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        TBASEGURAMIENTOS.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
