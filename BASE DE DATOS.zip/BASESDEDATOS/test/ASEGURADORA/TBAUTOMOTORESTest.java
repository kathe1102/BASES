/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ASEGURADORA;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author SEBASTIAN
 */
public class TBAUTOMOTORESTest {
    
    public TBAUTOMOTORESTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of cargatabla method, of class TBAUTOMOTORES.
     */
    @Test
    public void testCargatabla() {
        System.out.println("cargatabla");
        TBAUTOMOTORES instance = new TBAUTOMOTORES();
        instance.cargatabla();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of listardatos method, of class TBAUTOMOTORES.
     */
    @Test
    public void testListardatos() {
        System.out.println("listardatos");
        TBAUTOMOTORES instance = new TBAUTOMOTORES();
        instance.listardatos();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of registrar method, of class TBAUTOMOTORES.
     */
    @Test
    public void testRegistrar() {
        System.out.println("registrar");
        TBAUTOMOTORES instance = new TBAUTOMOTORES();
        instance.registrar();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of cargarcombo method, of class TBAUTOMOTORES.
     */
    @Test
    public void testCargarcombo() {
        System.out.println("cargarcombo");
        TBAUTOMOTORES instance = new TBAUTOMOTORES();
        instance.cargarcombo();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of cargarcombo2 method, of class TBAUTOMOTORES.
     */
    @Test
    public void testCargarcombo2() {
        System.out.println("cargarcombo2");
        TBAUTOMOTORES instance = new TBAUTOMOTORES();
        instance.cargarcombo2();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of modificar method, of class TBAUTOMOTORES.
     */
    @Test
    public void testModificar() {
        System.out.println("modificar");
        String mar = "";
        String tip = "";
        String mod = "";
        String pas = "";
        String cil = "";
        String cha = "";
        String pla = "";
        TBAUTOMOTORES instance = new TBAUTOMOTORES();
        instance.modificar(mar, tip, mod, pas, cil, cha, pla);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of eliminar method, of class TBAUTOMOTORES.
     */
    @Test
    public void testEliminar() {
        System.out.println("eliminar");
        String cod = "";
        TBAUTOMOTORES instance = new TBAUTOMOTORES();
        instance.eliminar(cod);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class TBAUTOMOTORES.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        TBAUTOMOTORES.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
