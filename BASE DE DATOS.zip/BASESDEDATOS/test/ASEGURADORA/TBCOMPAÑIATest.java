/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ASEGURADORA;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author SEBASTIAN
 */
public class TBCOMPAÑIATest {
    
    public TBCOMPAÑIATest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of cargatabla method, of class TBCOMPAÑIA.
     */
    @Test
    public void testCargatabla() {
        System.out.println("cargatabla");
        TBCOMPAÑIA instance = new TBCOMPAÑIA();
        instance.cargatabla();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of listardatos method, of class TBCOMPAÑIA.
     */
    @Test
    public void testListardatos() {
        System.out.println("listardatos");
        TBCOMPAÑIA instance = new TBCOMPAÑIA();
        instance.listardatos();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of registrar method, of class TBCOMPAÑIA.
     */
    @Test
    public void testRegistrar() {
        System.out.println("registrar");
        TBCOMPAÑIA instance = new TBCOMPAÑIA();
        instance.registrar();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of cargarcombo method, of class TBCOMPAÑIA.
     */
    @Test
    public void testCargarcombo() {
        System.out.println("cargarcombo");
        TBCOMPAÑIA instance = new TBCOMPAÑIA();
        instance.cargarcombo();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of modificar method, of class TBCOMPAÑIA.
     */
    @Test
    public void testModificar() {
        System.out.println("modificar");
        String nom = "";
        String fun = "";
        String rep = "";
        String nit = "";
        TBCOMPAÑIA instance = new TBCOMPAÑIA();
        instance.modificar(nom, fun, rep, nit);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of eliminar method, of class TBCOMPAÑIA.
     */
    @Test
    public void testEliminar() {
        System.out.println("eliminar");
        String cod = "";
        TBCOMPAÑIA instance = new TBCOMPAÑIA();
        instance.eliminar(cod);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class TBCOMPAÑIA.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        TBCOMPAÑIA.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
